#!/usr/bin/env python3
"""
    Author: Kyler David
    Email: kdavid1@madisoncollege.edu
    Description: Semester-long course project script which will analyze 
    an Apache web log to determine current threats.
"""
strUserInput = input("What is your name?\n>>>>")
print(f"Welcome, {strUserInput}!")
